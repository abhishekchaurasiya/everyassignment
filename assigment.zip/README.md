# thorium
Backend cohort Feb 2022 - May 2022
